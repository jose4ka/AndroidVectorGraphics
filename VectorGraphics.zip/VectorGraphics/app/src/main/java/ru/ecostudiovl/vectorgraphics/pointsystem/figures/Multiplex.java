package ru.ecostudiovl.vectorgraphics.pointsystem.figures;

public class Multiplex extends JFigure {
    public Multiplex(String name) {
        super(false, false, 0, name);
    }
}
