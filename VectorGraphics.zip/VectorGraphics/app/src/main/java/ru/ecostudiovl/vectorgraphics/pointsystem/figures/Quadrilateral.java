package ru.ecostudiovl.vectorgraphics.pointsystem.figures;

public class Quadrilateral extends JFigure {

    public Quadrilateral(String name){
        super(true,false, 4, name);
    }

}
