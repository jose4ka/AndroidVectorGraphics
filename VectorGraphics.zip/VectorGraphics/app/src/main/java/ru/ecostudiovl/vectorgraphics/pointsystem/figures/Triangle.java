package ru.ecostudiovl.vectorgraphics.pointsystem.figures;

public class Triangle extends JFigure {


    public Triangle(String name){
        super(true,false, 3, name);

    }



}
